$(function(){
    skrollr.init({
    forceHeight: false
});
});